import RegisterUser from "./features/registerUser/registerUserComponent";
import LoginComponent from "./features/loginUser/loginComponent";
import ForgotPasswordComponent from"./features/loginUser/forgotPasswordComponent";
import LandingPageComponent from "./features/landingPage/landingPageComponent";
import UpdateTweetComponent from "./features/updateTweet/updateTweetComponent";
import ReTweetComponent from "./features/reTweet/reTweetComponent";
import ViewReTweetsComponent from "./features/reTweet/viewRetweets";
import { BrowserRouter, Route, Switch } from "react-router-dom";

import './App.css';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
          <Switch>
            <Route exact path="/">
            <RegisterUser/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/login">
            <LoginComponent/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/forgot">
            <ForgotPasswordComponent/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/home">
            <LandingPageComponent tabType={"addTweet"}/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/logout">
            <LoginComponent />
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/addTweet">
            <LandingPageComponent tabType={"addTweet"}/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/users">
            <LandingPageComponent tabType={"users"}/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/myTweets">
            <LandingPageComponent tabType={"myTweets"}/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/allTweets">
            <LandingPageComponent tabType={"allTweets"}/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/update">
            <UpdateTweetComponent/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/viewreTweet">
            <ViewReTweetsComponent/>
            </Route>
          </Switch>
          <Switch>
            <Route exact path="/reTweet">
            <ReTweetComponent/>
            </Route>
          </Switch>
     </BrowserRouter>
    </div>
  );
}

export default App;
