import axios from "axios";
import * as React from "react";
import { UserDetails } from "../model/UserDetails";
import profile from "../images/profile.png";
import "./displayAllUserComponent.css"
interface Props { }

interface State {
    userDetails: UserDetails[]
    searchedUserDetails: UserDetails[]
    searchText: string;
    searched: boolean;
}

class DisplayAllUsers extends React.Component<Props, State>{

    constructor(props: Props) {
        super(props);
        this.state = {
            userDetails: [],
            searchedUserDetails: [],
            searchText: "",
            searched: false
        }

    }

    componentDidMount() {
        this.getUserDetails();
    }
    getUserDetails = () => {
        axios.get("http://localhost:8083/api/v1.0/tweets/users/all").then(
            (response) => {
                if (response.data !== null) {
                    this.setState({ userDetails: response.data })
                }
                else {
                    alert("something went wrong");
                    return;
                }
            }
        )
    }
    onChangeHandler = (event: any) => {
        this.setState({ searchText: event.target.value })
    }
    findUsers = () => {
        const userName = this.state.searchText;
        this.setState({ searched: true });
        axios.get("http://localhost:8083/api/v1.0/tweets/user/search/" + userName).then(
            (response) => {
                if (response.data !== null) {
                    this.setState({ searchedUserDetails: response.data });
                }
                else {
                    alert('no such user');
                    this.getUserDetails()
                }
            }
        )
    }
    renderSearchBar = () => {
        return (
            <div className="example" >
                <input type="text" value={this.state.searchText} name="search" onChange={this.onChangeHandler} />
                <button type="submit" onClick={this.findUsers}>Search</button>
            </div>

        )
    }
    renderUserDetails = (userDetails: UserDetails[]) => {
        return (
            userDetails &&
            userDetails.map((user: UserDetails) => {
                return (
                    <div className="card" style={{ height: "400px", marginLeft: "55px" }}>
                        <img src={profile} alt="img" style={{ width: "100%" }} />
                        <div className="container">
                            <h4><b>{user.firstName + "," + user.lastName}</b></h4>
                            <p className="email">{user.emailId}</p>
                        </div>
                    </div>
                )
            })
        )

    }
    render() {
        return (
            <>
                <div>
                    {this.renderSearchBar()}
                </div>
                <div>
                    {this.state.searched ? this.renderUserDetails(this.state.searchedUserDetails) : this.renderUserDetails(this.state.userDetails)}
                </div>
            </>

        )

    }
}

export default DisplayAllUsers;