import axios from "axios";
import * as React from "react";
import { TweetDetails } from "../model/TweetDetails";
import { withRouter, RouteComponentProps } from "react-router-dom";
interface State {
    tweetDetails: TweetDetails[];
}

interface Props extends RouteComponentProps<{}> {
    tweetType?: string
}

class MyTweetsComponent extends React.Component<Props, State>
{
    constructor(props: Props) {
        super(props)
        this.state = {
            tweetDetails: []
        }
    }
    componentDidMount() {
        this.getTweetDetails()
    }
    getTweetDetails = () => {
        let email = localStorage.getItem("userDetails");
        if (this.props.tweetType === "myTweets") {
            axios.get("http://localhost:8083/api/v1.0/tweets/myTweets/" + email).then(
                (response) => {
                    if (response.data !== null) {
                        this.setState({ tweetDetails: response.data })
                    }
                }
            )
        }
        else if (this.props.tweetType === "allTweets") {
            axios.get("http://localhost:8083/api/v1.0/tweets/allTweets").then(
                (response) => {
                    if (response.data !== null) {
                        this.setState({ tweetDetails: response.data })
                    }
                }
            )
        }
    }

    render() {
        const { tweetDetails } = this.state;
        const likeHandler = (id: String, emailId: String | null) => {
            axios.post("http://localhost:8083/api/v1.0/tweets/likeTweet/" + id + "/" + emailId).then(
                (response) => {
                    if (response.data !== null) {
                        this.getTweetDetails()
                    }
                }
            )
        }
        const deleteHandler = (id: any) => {
            axios.delete("http://localhost:8083/api/v1.0/tweets/deleteTweet/" + id).then(
                (response) => {
                    if (response.data === "deleted") {
                        alert("tweet has been deleted successfully");
                        this.getTweetDetails()
                    }
                }
            )
        }
        const updateHandler = (tweet: TweetDetails) => {
            this.props.history.push({
                pathname: '/update',
                state: {
                    tweet: tweet,
                    tab: this.props.tweetType
                },
            })
        }
        const reTweetHandler = (tweet: TweetDetails) => {
            this.props.history.push({
                pathname: '/reTweet',
                state: {
                    tweet: tweet,
                    tab: this.props.tweetType
                },
            })
        }
        const viewReTweetHandler = (id: string) => {
            this.props.history.push({
                pathname: '/viewreTweet',
                state: {
                    tweetId: id,
                },
            })
        }
        return (
            tweetDetails &&
            tweetDetails.map((tweet: TweetDetails) => {
                return (
                    <>
                        <div className="container" style={{ margin: "25px", height: "150px", maxWidth: "1500px" }}>
                            <p><span>{tweet.tweet}</span></p>
                            <p>Number Of Likes : {tweet.likeCount}</p>
                            {this.props.tweetType === "allTweets" && <button name="like" style={{ margin: "25px", width: "150px" }} onClick={() => { likeHandler(tweet.id, localStorage.getItem("email")) }}>LikeTweet</button>}
                            {this.props.tweetType === "myTweets" && <button name="Delete" style={{ margin: "25px", width: "150px" }} onClick={() => { deleteHandler(tweet.id) }}>DeleteTweet</button>}
                            <button name="Reply" style={{ margin: "25px", width: "150px" }} onClick={() => { reTweetHandler(tweet) }}>ReplyTweet</button>
                            {this.props.tweetType === "myTweets" && <button name="Reply" style={{ margin: "25px", width: "150px" }} onClick={() => { updateHandler(tweet) }}>UpdateTweet</button>}
                            <button name="Reply" style={{ margin: "25px", width: "180px" }} onClick={() => { viewReTweetHandler(tweet.id) }}>Replied Tweets</button>
                        </div>
                    </>
                )
            })

        )
    }
}

export default withRouter(MyTweetsComponent);