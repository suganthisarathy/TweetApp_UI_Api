import RegisterUserComponent from "./registerUserComponent";
import { mount } from "enzyme"

describe("Register Component", () => {
    let wrapper: any;
    beforeEach(() => {
        wrapper = mount(<RegisterUserComponent />);
    });

    test("Rendering the component", () => {
        expect(wrapper.exists()).toBeTruthy();
    });


});