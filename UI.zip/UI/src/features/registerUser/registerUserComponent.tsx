import axios from "axios";
import * as React from "react";
import "./registerUserComponent.css";

interface Props {

}

interface State {
  firstName: string;
  lastName: string;
  gender: string;
  dob: string;
  email: string;
  password: string;
  isFirstNameValid: boolean;
  isSecondNameValid: boolean;
  isdobValid: boolean;
  isEmailValid: boolean;
  isPasswordValid: boolean;
  isLastNameValid: boolean;
}

class RegisterUserComponent extends React.Component<Props, State>{

  constructor(props: Props) {
    super(props);

    this.state = {
      firstName: "",
      lastName: "",
      gender: "",
      dob: "",
      email: "",
      password: "",
      isFirstNameValid: true,
      isLastNameValid: true,
      isSecondNameValid: true,
      isdobValid: true,
      isEmailValid: true,
      isPasswordValid: true,
    }
  }

  render() {
    const { firstName, lastName, gender, dob, email, password } = this.state;

    const onChangeHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ ...this.state, [event.target.id]: event.target.value });
    };

    const genderChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
      this.setState({ ...this.state, [event.target.id]: event.target.value });
    }

    const isAgeValid = () => {
      let dob = this.state.dob;
      let bday = dob.split("-");
      var bday_in_milliseconds = new Date(parseInt(bday[2], 10), parseInt(bday[1], 10) - 1, parseInt(bday[0]), 10).getTime(); //birth-date in milliseconds
      var now = new Date().getTime(); //current time in milliseconds
      if (now - bday_in_milliseconds > 567648000000) { //567648000000 is 18 years in milliseconds
        this.setState({ isdobValid: true });
      }
      else {
        this.setState({ isdobValid: false });
      }
    }

    const validateFields = (user: any) => {
      isAgeValid();
      this.setState({ isEmailValid: (user.emailId.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) ? true : false) });
      this.setState({ isPasswordValid: (user.password.length >= 6 ? true : false) });
      this.setState({ isFirstNameValid: (user.firstName.match("[a-zA-Z]{3,30}\s*") ? true : false) });
      this.setState({ isSecondNameValid: (user.lastName.match("[a-zA-Z]{3,30}") ? true : false) });
      if (this.state.isEmailValid && this.state.email !== "" && this.state.lastName != "" && this.state.email !== "" && this.state.password != "" && this.state.isPasswordValid && this.state.isdobValid && this.state.isFirstNameValid && this.state.isSecondNameValid)
        return true;
      else
        return false;

    }

    const submitHandler = () => {
      const user = {
        id: Math.random().toString(36).substr(1, 5),
        firstName: this.state.firstName,
        lastName: this.state.lastName,
        gender: this.state.gender,
        dob: this.state.dob,
        emailId: this.state.email,
        password: this.state.password,
      };
      if (validateFields(user))
        axios.post("http://localhost:8083/api/v1.0/tweets/register", user).then(
          response => {
            if (response.data === "success") {
              alert('user registered successfully,please login to continue')
              this.setState({
                firstName: "",
                lastName: "",
                gender: "",
                dob: "",
                email: "",
                password: "",
                isFirstNameValid: true,
                isLastNameValid: true,
                isSecondNameValid: true,
                isdobValid: true,
                isEmailValid: true,
                isPasswordValid: true,
              });
            }
            else if (response.data === "exsist") {
              alert('email already exsist,try with another email')
            }
            else {
              alert('something went wrong');
            }
          }
        ).catch(error => {
          console.log(error)
        })
    }
    return (
      <>
        <div className="container" style={{ justifyContent: "center" }}>
          <div className="title">Registration</div>
          <div className="content">
            <div className="user-details">
              <div className="input-box">
                {!this.state.isFirstNameValid ? <div style={{ color: "red" }}>Invalid First Name</div> : null}
                <span className="details">
                  FirstName:
                  <input type="text" id="firstName" value={firstName} onChange={onChangeHandler} />
                </span>
              </div>
              <div className="input-box">
                {!this.state.isLastNameValid ? <div style={{ color: "red" }}>Invalid Last Name</div> : null}
                <span className="details">
                  LastName:
                  <input type="text" id="lastName" value={lastName} onChange={onChangeHandler} />
                </span>
              </div>
              <div className="input-box">
                <span className="details">
                  Gender:
                  <select className="details" value={this.state.gender} id="gender" name="gender" onChange={(event) => genderChange(event)}>
                    <option id="gender" value="Select">Select</option>
                    <option id="gender" value="Male">Male</option>
                    <option id="gender" value="Female">Female</option>
                    <option id="gender" value="Other">Other</option>
                  </select>
                </span>
              </div>
              <div className="input-box">
                {/*** --Age should be greater than 18-**/}
                {!this.state.isdobValid ? <div style={{ color: "red" }}>Invalid DOB</div> : null}
                <span className="details">
                  DOB:
                  <input type="text" id="dob" value={dob} onChange={onChangeHandler} />
                </span>
              </div>
              <div className="input-box">
                {!this.state.isEmailValid ? <div style={{ color: "red" }}>Email Format Invalid </div> : null}
                <span className="details">
                  Email:
                  <input type="text" id="email" value={email} onChange={onChangeHandler} />
                </span>
              </div>
              <div className="input-box">

                {!this.state.isPasswordValid ? <div style={{ color: "red" }}>Password Format Invalid </div> : null}
                <span className="details">
                  Password:
                  <input type="password" id="password" value={password} onChange={onChangeHandler} />
                </span>
              </div>
              <button type="submit" className="button"
                onClick={submitHandler}>
                Submit
              </button>
              <div className="input-box">
                <span className="details">
                  Already have an account?
                  <a href="/login">SignIn</a>
                </span>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }

}

export default RegisterUserComponent;