export interface UserDetails {
    id: string,
    firstName: string,
    lastName: string,
    gender: string,
    dob: string,
    emailId: string,
    status: boolean;

}

