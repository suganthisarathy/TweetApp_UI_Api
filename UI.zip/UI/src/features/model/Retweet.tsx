export interface ReTweet{
    reTweetId?:string;
    parentTweetId:string;
    retweet:string;
    reTweetLikeCount?:string;
}