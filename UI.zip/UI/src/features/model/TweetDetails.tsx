export interface TweetDetails
{
    id:string;
    tweet:string,
    likeCount:number,
    emailId:string,
    userName:string,
}