import axios from "axios";
import * as React from "react";
import { withRouter, RouteComponentProps } from "react-router-dom";
import "../registerUser/registerUserComponent.css";

interface Props extends RouteComponentProps<{}> { }

interface State {
  email: string;
  password: string;
  confirmPassword: string;
}

class ForgotPasswordComponent extends React.Component<Props, State>{

  constructor(props: Props) {
    super(props);

    this.state = {
      email: "",
      password: "",
      confirmPassword: ""
    }
  }

  componentDidMount() {

  }

  render() {
    const { email, password, confirmPassword } = this.state;

    const onChangeHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ ...this.state, [event.target.id]: event.target.value });
    };

    const submitHandler = () => {
      if (this.state.password !== this.state.confirmPassword) {
        alert("password mismatch")
      }
      else {
        const loginDetails = {
          email: this.state.email,
          password: this.state.password

        }
        axios.post("http://localhost:8083/api/v1.0/tweets/forgot", loginDetails).then(
          response => {

            if (response.data === "no such user") {
              alert('user doesnot exsist,please register your account')
            }
            else {
              alert('password has been reset successfully,please login to continue')
              this.props.history.push("/");
            }
          }
        ).catch(error => {
          console.log(error)
        })

      }

    }
    return (

      <>
        <div className="container" style={{ justifyContent: "center" }}>
          <div className="title">Login</div>
          <div className="content">
            <div className="user-details">
              <div className="input-box">
                <label>
                  email:
                  <input type="text" id="email" value={email} onChange={onChangeHandler} />
                </label>
              </div>
              <div className="input-box">
                <label>
                  password:
                  <input type="password" id="password" value={password} onChange={onChangeHandler} />
                </label>
              </div>
              <div className="input-box">
                <label>
                  Confirm password:
                  <input type="password" id="confirmPassword" value={confirmPassword} onChange={onChangeHandler} />
                </label>
              </div>
              <button type="submit" className="button"
                onClick={submitHandler}>
                submit
              </button>
            </div>
          </div>
        </div>
      </>


    )
  }
}

export default withRouter(ForgotPasswordComponent);



