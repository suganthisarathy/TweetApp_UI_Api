import axios from "axios";
import * as React from "react";
import { withRouter, RouteComponentProps } from "react-router-dom";
import "../registerUser/registerUserComponent.css";

interface Props extends RouteComponentProps<{}> {
}
interface State {
  email: string;
  password: string;
  isEmailValid: boolean;
  isPasswordValid: boolean;
  error: boolean;
  errorMessage: string;
}

class LoginComponent extends React.Component<Props, State>{

  constructor(props: Props) {
    super(props);

    this.state = {
      email: "",
      password: "",
      isEmailValid: true,
      isPasswordValid: true,
      errorMessage: "",
      error: false
    }
  }


  render() {
    const { email, password } = this.state;

    const onChangeHandler = (event: React.ChangeEvent<HTMLInputElement>) => {
      this.setState({ ...this.state, [event.target.id]: event.target.value });
    };

    const validateData = (loginDetails: any) => {

      this.setState({ isEmailValid: (loginDetails.email.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) ? true : false) });
      this.setState({ isPasswordValid: (loginDetails.password.length >= 6 ? true : false) });
      return (this.state.isPasswordValid && this.state.isEmailValid) ? true : false;
    }

    const submitHandler = () => {
      const loginDetails = {
        email: this.state.email,
        password: this.state.password

      }

      const isDataValid = validateData(loginDetails);

      if (isDataValid)
        axios.post("http://localhost:8083/api/v1.0/tweets/login", loginDetails).then(
          response => {
            if (response.data === "password mismatch") {
              this.setState({ error: true, errorMessage: "Password Mismatch" });
              //alert('password wrong,please enter valid credentials')
            }
            else if (response.data === "no such user") {
              this.setState({ error: true, errorMessage: `${this.state.email} does not exist` });
              // alert('user doesnot exsist,please register your account')
            }
            else {
              localStorage.setItem("userDetails", response.data);
              this.props.history.push("/home");
            }
          }
        ).catch(error => {
          console.log(error)
        })
    }
    return (

      <>
        <div className="container" style={{ justifyContent: "center" }}>
          <div className="title">Login</div>
          <div className="content">
            <div className="user-details">
              <div className="input-box">
                {!this.state.isEmailValid ? <div style={{ color: "red" }}>Email Format Invalid </div> : null}
                <label>
                  email:
                  <input type="text" id="email" value={email} onChange={onChangeHandler} />
                </label>
              </div>
              <div className="input-box">
                {!this.state.isPasswordValid ? <div style={{ color: "red" }}>Password Format Invalid </div> : null}
                <label>
                  password:
                  <input type="password" id="password" value={password} onChange={onChangeHandler} />
                </label>
              </div>
              <button type="submit" className="button"
                onClick={submitHandler}>
                submit
              </button>
              {this.state.error && <div style={{ color: "red" }}>

                {this.state.errorMessage}

              </div>}
              <div className="input-box">


                <a href="/forgot"> Forgot Password?</a>

              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default withRouter(LoginComponent);



