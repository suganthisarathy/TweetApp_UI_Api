import axios from "axios";
import * as React from "react";
import { ReTweet } from "../model/Retweet"
import { withRouter, RouteComponentProps } from "react-router-dom";
interface State {
    tweetDetails: ReTweet[];
    id: any;
}

interface Props extends RouteComponentProps<{}> {
}

class ViewReTweetsComponent extends React.Component<Props, State>
{
    constructor(props: Props) {

        super(props)
        const tweetId: any = props.history.location.state;
        this.state = {
            tweetDetails: [],
            id: tweetId
        }
    }
    componentDidMount() {
        this.getTweetDetails();
    }
    getTweetDetails = () => {
        const { tweetId } = this.state.id;

        axios.get(`http://localhost:8083/api/v1.0/tweets/replyTweets/${tweetId}`).then(
            (response) => {
                if (response.data !== null) {
                    this.setState({ tweetDetails: response.data })
                }
            }
        )
    }

    render() {
        const { tweetDetails } = this.state;

        return (
            tweetDetails &&
            tweetDetails.map((tweet: ReTweet) => {
                return (
                    <>
                        <div className="container" style={{ margin: "25px", height: "150px", maxWidth: "1500px" }}>
                            <p><span>{tweet}</span></p>
                        </div>
                    </>
                )
            })

        )
    }
}

export default withRouter(ViewReTweetsComponent);