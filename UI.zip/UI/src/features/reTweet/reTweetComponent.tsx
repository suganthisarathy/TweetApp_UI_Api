import axios from "axios";
import React from "react";
import { withRouter, RouteComponentProps } from "react-router-dom";
import { TweetDetails } from "../model/TweetDetails";
import { ReTweet } from "../model/Retweet"
import NavBarComponent from "../landingPage/navBarComponent/navBarComponent";
interface State {
    tweetDetail: TweetDetails;
    reTweet: ReTweet;
}

interface Props extends RouteComponentProps<{}> {

}

class ReTweetComponent extends React.Component<Props, State>
{
    constructor(props: Props) {
        const tweet: any = props.history.location.state
        const twt: any = tweet.tweet
        super(props)
        this.state = {
            tweetDetail: twt,
            reTweet: {} as ReTweet
        }
        console.log(props.history.location.state)

    }



    render() {

        const onChangeHandler = (event: any) => {
            const reTweet = event.target.value;
            const twt = {
                reTweetId: Math.random().toString(36).substr(3, 5),
                parentTweetId: this.state.tweetDetail.id,
                retweet: reTweet,

            }
            this.setState({ reTweet: twt })
        }
        const submitHandler = (event: any) => {

            event.preventDefault();
            if (this.state.reTweet.retweet === "") {
                alert('post some content');
                return;
            }

            axios.post("http://localhost:8083/api/v1.0/tweets/postReTweet", this.state.reTweet).then(
                (response => {
                    if (response.data !== null) {
                        alert('tweet updated successfully')
                        this.props.history.push("/home");
                    }
                    else {
                        alert('something went wrong')
                        this.props.history.push("/home");
                    }
                })
            )

        }
        return (
            <>
                <NavBarComponent />
                <div style={{ margin: "150px", justifyContent: "center" }}>
                    <h1>Please Provide Retweet for the following  tweet!!!</h1>
                    <p>{this.state.tweetDetail.tweet}</p>
                    <textarea id="tweet" value={this.state.reTweet.retweet} rows={4} cols={50}
                        onChange={onChangeHandler}
                    />
                    <button type="submit" className="btn"
                        onClick={submitHandler}>
                        submit
                    </button>
                </div>
            </>
        )
    }
}

export default withRouter(ReTweetComponent)