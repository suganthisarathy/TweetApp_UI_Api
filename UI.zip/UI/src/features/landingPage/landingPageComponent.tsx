import React ,{ Component } from "react";
import NavBarComponent from "./navBarComponent/navBarComponent";
import ProfileCardComponent from "../landingPage/profileCard/profileCardComponent";
import AddTweetComponent from "../addTweet/addTweetComponent";
import DisplayAllUsers from "../Users/displayAllUsersComponent";
import MyTweetsComponent from "../myTweets/myTweetsComponent";
interface State{}

export interface LocalProps {
    tabType?:string;
}

class LandingPageComponent extends Component<LocalProps,State>
{
  
    constructor(props:LocalProps)
    {
        super(props);
        this.state ={

        }
    }

    render()
    {
        
        return(<>
        <NavBarComponent/>
        {(this.props.tabType==="addTweet")&& <ProfileCardComponent/>}
        {this.props.tabType==="addTweet" && <AddTweetComponent/>}
        {this.props.tabType==="users" && <DisplayAllUsers/>}
        {this.props.tabType==="myTweets" && <MyTweetsComponent tweetType={"myTweets"}/>}
        {this.props.tabType==="allTweets" && <MyTweetsComponent tweetType={"allTweets"}/>}
        
        </>)
    }
}

export default LandingPageComponent;