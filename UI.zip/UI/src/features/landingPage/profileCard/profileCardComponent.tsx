import React from "react";
import axios from "axios";
import "./profileCardComponent.css";
import { UserDetails } from "../../model/UserDetails"
import profile from "../../images/profile.png";
interface State {
    userDetails: UserDetails
}

interface Props { }

class ProfileCardComponent extends React.Component<Props, State>
{

    constructor(props: Props) {
        super(props);
        this.state = {
            userDetails: {} as UserDetails
        }
    }

    componentDidMount() {
        let email = localStorage.getItem("userDetails");
        console.log(email);
        axios.get("http://localhost:8083/api/v1.0/tweets/users/" + email).then(
            response => {
                if (response.data != null) {
                    this.setState({ userDetails: response.data }, () => {
                        localStorage.setItem("email", this.state.userDetails.emailId)
                        localStorage.setItem("userName", this.state.userDetails.firstName + this.state.userDetails.lastName);
                        localStorage.setItem("id", this.state.userDetails.id)
                    });

                }
            }
        )
    }
    render() {
        const { userDetails } = this.state;
        return (<>
            <div className="card">
                <img src={profile} alt="img" style={{ width: "100%" }} />
                <h1>{userDetails.firstName},{userDetails.lastName}</h1>
                <p className="title">{userDetails.gender}</p>
                <p>{userDetails.dob}</p>
                <p><button>{userDetails.emailId}</button></p>
            </div>

        </>)
    }
}

export default ProfileCardComponent;