
import axios from "axios";
import React from "react"
import "./navbarComponent.css";
interface State { }

interface Props { }

class NavBarComponent extends React.Component<Props, State>{

    constructor(props: Props) {
        super(props)
        this.state = {

        }
    }

    logOut = () => {
        const email = localStorage.getItem("email");
        const URL = `http://localhost:8083/api/v1.0/tweets/logout/${email}`;
        axios.post(URL).then((res) => {
            alert(res.data);
        }).catch((err) => {
            console.log(err);
        });
    }

    render() {


        return (
            <>
                <div className="topnav">
                    <a className="active" href="#home">TweetApp</a>
                    <a href="/addTweet">AddTweet</a>
                    <a href="/myTweets">MyTweets</a>
                    <a href="/allTweets">AllTweets</a>
                    <a href="/users">Users</a>
                    <a href="/logout" onClick={() => { this.logOut() }}>Logout</a>
                </div>
            </>
        )
    }
}

export default NavBarComponent;