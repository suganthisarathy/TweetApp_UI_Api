import AddTweetComponent from "./addTweetComponent";
import { mount } from "enzyme";
import { Props } from "./addTweetComponent"
import { MemoryRouter } from 'react-router';
describe("AddTweetComponent", () => {


    let wrapper: any;
    let props = {

    }
    beforeEach(() => {
        wrapper = mount(<MemoryRouter><AddTweetComponent {...props} /></MemoryRouter>)
    });
    test("Rendering component", () => {

    });
});