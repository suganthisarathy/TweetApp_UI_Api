import axios from "axios";
import React from "react";
import { withRouter, RouteComponentProps } from "react-router-dom";
import "./addTweetComponent.css";
interface State {
    tweet: string;
    email: string | null;
}

export interface Props extends RouteComponentProps<{}> { }

class AddTweetComponent extends React.Component<Props, State>
{
    constructor(props: Props) {
        super(props)
        this.state = {
            tweet: "",
            email: localStorage.getItem('email')
        }
    }



    render() {

        const onChangeHandler = (event: any) => {
            this.setState({ tweet: event.target.value })
        }
        const submitHandler = (event: any) => {
            event.preventDefault();
            if (this.state.tweet === "") {
                alert('post some content');
                return;
            }
            const tweet = {
                id: Math.random().toString(36).substr(2, 5),
                emailId: this.state.email,
                userName: localStorage.getItem('userName'),
                tweet: this.state.tweet
            }
            axios.post("http://localhost:8083/api/v1.0/tweets/postNewTweet", tweet).then(
                (response => {
                    if (response.data !== null) {
                        alert('post added successfully')
                        this.props.history.push("/addTweet");
                    }
                    else {
                        alert('something went wrong')
                        this.props.history.push("/");
                    }
                })
            )
            this.setState({ tweet: "" })
        }
        return (
            <>
                <h1>Welcome to TweetApp,Post Your Tweet!!!</h1>
                <textarea id="tweet" value={this.state.tweet} rows={4} cols={50}
                    onChange={onChangeHandler}
                />
                <button type="submit" className="btn"
                    onClick={submitHandler}>
                    submit
                </button>
            </>
        )
    }
}

export default withRouter(AddTweetComponent)